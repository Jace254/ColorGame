package com.example.colorgame

import android.widget.ImageView
import android.widget.ProgressBar

data class ColorAnimal(val name: String,val image: ImageView)

data class GameData(val level: Int,val progress: ProgressBar)