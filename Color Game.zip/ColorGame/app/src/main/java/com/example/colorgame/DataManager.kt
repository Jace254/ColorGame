package com.example.colorgame

class DataManager {
}